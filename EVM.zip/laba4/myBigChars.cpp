#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "myTerm.h"

int bc_box(int x1, int y1, int x2, int y2) {
	char buf[100];
	unsigned int chk;
	int a, b;
	
	chk = mt_getscrinsize(&a, &b);
	
	sprintf(buf, "%s", "\E(0");
	chk = write(1, buf, strlen(buf));
	for (int i = 0; i < b	; ++i) {
		chk = write(1, "q", 1);
	}
	sprintf(buf, "%s", "\E(B");
	chk = write(1, buf, strlen(buf));
	if (chk == strlen(buf))
		return 0;
	else
		return -1;
}
int main() {
	int chk1;
	
	chk1 = bc_box(1, 1, 1, 10);
	return 0;
}
