#include <stdio.h>

int main() {
	
	int i = 3;
	
	printf("%d", i<<6);
	return 0;
}
