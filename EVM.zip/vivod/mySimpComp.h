#ifndef __GUARD_MYSIMPLECOMPUTER_H
#define __GUARD_MYSIMPLECOMPUTER_H

#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define BIT_SET(A, B) ((A | (1 << (B))))
#define BIT_CLEAR(A, B) ((A & ~(1 << (B))))
#define BIT_GET(A, B) ((A >> B) & 1)

#define OVERFLOW 1
#define DIV_BY_0 2
#define MEM_BRD 3
#define IGN_CLCK 4
#define WRNG_CMD 5


#define MSIZE 100
#define CMDNUM 38

extern const int commands[];
							
int sc_memory[MSIZE];
int sc_reg_flags;

int sc_memoryInit();
int sc_regSet(int reg, int value);
int sc_memorySet(int addr, int value);
int sc_memoryGet(int addr, int *value);
int sc_memorySave(char *filename);
int sc_memoryLoad(char *filename);
int sc_regInit();
int sc_regGet(int reg, int *value);
int sc_commandEncode(int command, int operand, int *value);
int sc_commandDecode(int value, int *command, int *operand);

#endif
