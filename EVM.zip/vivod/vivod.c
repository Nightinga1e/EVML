#include <stdio.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>

#include "mySimpComp.h"	
#include "myTerm.h"
#include "myBigChars.h"
#include "myReadKey.h"

int activity;
int accumulator;
int instrcount = 0;

void time_handl(int sig);
void printterm();

void usr1_handl(int sig)
{
	alarm(0);
	
	sc_regInit();
	
	sc_regSet(IGNORING, 1);
	activity = 0;
	instrcount = 0;
	
	printterm();
}

void time_handl(int sig)
{
	int per;
	instrcount++;
	activity++;
	printterm();
	sc_regGet(IGNORING, &per);
	if (per == 0)
		alarm(1);
}
void printterm()
{
	int x, y, ck;
	char buf[100];
	{//memory
		bc_box(1, 1, 12, 62);
		mt_gotoXY(1, 27);
		sprintf(buf, " Memory ")	;
		ck = write(1, buf, strlen(buf));
		
		x = 2;
		y = 2;
		mt_gotoXY(x, y);
		for (int i = 0; i < 100; i++) {
			
			if (i == activity) {
				mt_setbgcolor(blue);
			}
			sprintf(buf, "+%4.4x ", sc_memory[i]);
			ck = write(1, buf, strlen(buf));
			
			if ( i%10 == 9) {
				x++;
				mt_gotoXY(x, y);
			}
			mt_setbgcolor(9);
		}
		
		
	}
	
	{//accumulator
		bc_box(1, 63, 3, 84);
		mt_gotoXY(1,68);
		sprintf(buf, " accumulator ")	;
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(2,71);
		sprintf(buf, "+%4.4d ", sc_memory[5]);
		ck = write(1, buf, strlen(buf));
	}
	{//inscount
		bc_box(4, 63, 6, 84);
		mt_gotoXY(4,64);
		sprintf(buf, " instructionCounter ")	;
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(5,71);
		sprintf(buf, "+%4.4d ", instrcount);
		ck = write(1, buf, strlen(buf));
	}
	{//operatoin
		int a, b;
		bc_box(7, 63, 9, 84);
		mt_gotoXY(7,69);
		sprintf(buf, " operation ")	;
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(8,71);
		ck = sc_commandDecode(sc_memory[activity], &a, &b);
		
		sprintf(buf, "+%2.2x : %2.2x ", a, b);
		ck = write(1, buf, strlen(buf));
	}
	{//flags
		bc_box(10, 63, 12, 84);
		mt_gotoXY(10,71);
		sprintf(buf, " flags ")	;
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(11,70);
		
		char m1[] = "AODIC", buf1[100];
		int fas = 0;
		for (int i = 0; i < 5; ++i) {
			ck = sc_regGet(i, &fas);
			if (fas == 1) {
				sprintf(buf1, "%c ", m1[i])	;
				ck = write(1, buf1, strlen(buf1));
			} else {
				sprintf(buf1, "  ")	;
				ck = write(1, buf1, strlen(buf1));
			}
		}
	}
	
	{//bigchar
		bc_box(13, 1, 22, 48);
		ck = bc_printbigchar(mass+16*2, 14, 2, gray, 9);
		sprintf(buf, "+%4.4x", sc_memory[activity]);
		for (int i = 1; i < 5; ++i) {
			int f = buf[i] - '0';
			if (f > 10) {
				f = f%49 + 10;
			}
			
			ck = bc_printbigchar(mass+f*2, 14, 3 + (8*i) + i, gray, 9);
		}
	}
	{//instructions
		bc_box(13, 49, 22, 84);
		mt_gotoXY(13,52);
		sprintf(buf, " keys: ")	;
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(14,52);
		sprintf(buf, "l  -  load");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(15,52);
		sprintf(buf, "s  -  save");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(16,52);
		sprintf(buf, "r  -  run");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(17,52);
		sprintf(buf, "t  -  step");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(18,52);
		sprintf(buf, "i  -  reset");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(19,52);
		sprintf(buf, "F5 -  accumulator");
		ck = write(1, buf, strlen(buf));
		mt_gotoXY(20,52);
		sprintf(buf, "F6 -  instructionCounter");
		ck = write(1, buf, strlen(buf));
	}
	
	sprintf(buf, "\n\n\n\n")	;
	ck = write(1, buf, strlen(buf));
}
int main() {
	enum keys k;
	int ch, v, ret;
	mt_clrscr();
	sc_memoryInit();
	sc_regInit();
	
	for (int i = 0; i < 100; ++i) {
		ch = sc_commandEncode(commands[i%38], i%99, &v);
		sc_memorySet(i, v);
	}
	activity = 0;
	sc_regSet(3,1);
	signal (SIGALRM, time_handl);
	signal (SIGUSR1, usr1_handl);
	
	printterm();
	k = 50;
	while(k != KEY_quit) {
		
		rk_readkey(&k);
		
		sc_regGet(IGNORING, &ret);
		if (ret == 1) {
			switch (k) {
				case KEY_l:
					ch = sc_memoryLoad("memory");
					break;
				case KEY_s:
					ch = sc_memorySave("memory");
					break;
				case KEY_down:
					if ((activity + 10) < 100) {
						activity = activity + 10;
						printterm();
					}
					break;
				case KEY_up:
					if ((activity - 10) >= 0) {
						activity = activity - 10;
						printterm();
					}
					break;
				case KEY_right:
					if ((activity + 1) < 100) {
						activity++;
						printterm();
					}
					break;
				case KEY_left:
					if ((activity - 1) >= 0) {
						activity--;
						printterm();
					}
					break;
				case KEY_t:
					time_handl(SIGALRM);
					break;
			}
		}
		switch (k) {
			case KEY_r:
				sc_regGet(IGNORING, &ret);
				if (ret == 1) {
					sc_regSet(IGNORING, 0);
					time_handl(SIGALRM);
				} else {
					alarm(0);
					sc_regSet(IGNORING, 1);
					printterm();
				}
				break;
			case KEY_i:
				raise(SIGUSR1);
				break;
		}
	}
	return 0;
}
