#include "myBigChars.h"

long long int mass[] = { 	2172748287, 8581644673,
							2155905152, 2155905152,
							2155905279, 4278256127,
							4286611711, 4286611584,
							2172748161, 2155905279,
							4278256127, 4286611584,
							16843263,   4286677503,
							2155905279, 2155905152,
							4286677503, 4286677377,
							4286677503, 4286611584,
							2168595480, 2172748287,
							2172731711, 4286677503,
							16843516, 4227989761,
							2172731711, 1061257601,
							16843263,   4278256127,
							16843263,   16843071,
							4279769112, 404232447};
							
int bc_printA(char *str) {
	unsigned int chk;
	char buf[200];
	
	sprintf(buf, "%s", "\E(0");
	chk = write(1, buf, strlen(buf));
	
	chk = write(1, str, strlen(str));
	
	sprintf(buf, "%s", "\E(B");
	chk = write(1, buf, strlen(buf));
	if (chk == strlen(buf))
		return 0;
	else
		return -1;
}

int bc_box(int x1, int y1, int x2, int y2) {
	char buf[100];
	unsigned int chk;
	
	sprintf(buf, "%s", "\E(0");
	
	chk = write(1, buf, strlen(buf));
	
	for (int i = 0; i < x2 - x1; ++i) {
		chk = mt_gotoXY(x1 + i, y1);
		chk = write(1, "x", 1);
		chk = mt_gotoXY(x1 + i, y2);
		chk = write(1, "x", 1);
	}
	
	chk = mt_gotoXY(x1, y1);
	for (int i = y1; i <= y2; ++i) {
		chk = write(1, "q", 1);
	}
	
	chk = mt_gotoXY(x2, y1);
	for (int i = y1; i <= y2; ++i) {
		chk = write(1, "q", 1);
	}
	
	chk = mt_gotoXY(x1, y1);
	chk = write(1, "l", 1);
	chk = mt_gotoXY(x2, y1);
	chk = write(1, "m", 1);
	chk = mt_gotoXY(x1, y2);
	chk = write(1, "k", 1);
	chk = mt_gotoXY(x2, y2);
	chk = write(1, "j", 1);
	
	chk = write(1, "\n", 1);
	
	sprintf(buf, "%s", "\E(B");
	chk = write(1, buf, strlen(buf));
	if (chk == strlen(buf))
		return 0;
	else
		return -1;
}

int bc_printbigchar(long long int *ii, int x, int y, enum color c1, enum color c2) {
	
	char buf[100];
	unsigned int chk;
	
	sprintf(buf, "%s", "\E(0");
	chk = write(1, buf, strlen(buf));
	
	mt_setfgcolor(c1);
	mt_setbgcolor(c2);

	int o = 0;
	for(int i = 0; i < 2; ++i) {
		int u = *(ii+i);
		for (int j = 0; j < 4; ++j) {
			char ger[9];
				for (int k = 0; k < 8; ++k) {
					if(u & 1) {
						ger[k] = 'a';
					} else ger[k] = ' ';
					u = u >> 1;
				}
				mt_gotoXY(x+j+o, y);
				chk = write(1, ger, 8);
		}
		o = o + 4;
	}
	sprintf(buf, "%s", "\E(B");
	chk = write(1, buf, strlen(buf));
	mt_setbgcolor(9);
	mt_setfgcolor(9);
	if (chk == strlen(buf))
		return 0;
	else
		return -1;
}

int bc_setbigcharpos(int *big, int x, int y, int value)
{
	int pos;

	if (x <= 3)
		pos = 0;
	else
		pos = 1;
		
	if (value == 0)
		big[pos] &= ~(1 << (y + x*8));
	else
		big[pos] |= 1 << (y + x*8);
	
	return 0;
}
int bc_getbigcharpos(int *big, int x, int y, int *value)
{
	int pos;

	if (x <= 3)
		pos = 0;
	else
		pos = 1;
		
	*value = (big[pos] >> (y + x*8)) & 1;
		
	return 0;
}
int bc_bigcharread(int fd, int *big, int need_count, int *count)
{
	int i;
	
	i = read(fd, big, need_count * sizeof(int) * 2);
	if (i == -1)
		return -1;
	*count = i / (sizeof(int) * 2);
	
	return 0;
}

int bc_bigcharwrite(int fd, int *big, int count)
{
	int i;
	
	i = write(fd, big, count * (sizeof(int)) * 2);
	if (i == -1)
		return -1;
	
	return 0;
}
