#include <stdio.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>

#include "myReadKey.h"

int d;

void kek(int sig) {
	printf("dvfgs");
}

void alrmfun(int sig) {
	alarm(0);
	printf("sdvfsd\n");
}
int main() {
	signal(SIGUSR1, alrmfun);
	signal(SIGALRM, kek);
	d = 0;
	int x = 1;
	
	enum keys k = 1;
	while(k!= 0) {
		 rk_readkey(&k);
		 switch (k) {
			 case KEY_t:
				raise(SIGUSR1);
				break;
			 default:
					x = x;
			}
	}
	return 0;
}
