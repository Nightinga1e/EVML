#ifndef __GUARD_MYSIMPLECOMPUTER_H
#define __GUARD_MYSIMPLECOMPUTER_H

#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define BIT_SET(A, B) ((A | (1 << (B))))
#define BIT_CLEAR(A, B) ((A & ~(1 << (B))))
#define BIT_GET(A, B) ((A >> B) & 1)


#define ERROR_ADDRESS -1 //ошибка адреса ОП
#define ERROR_OPEN_FILE -2 //файл не открылся
#define ERROR_FILE_WR -3 //ошибка записи\чтения файла
#define ERROR_VALUE -4 //неверное значение для флага !(0&1)
#define ERROR_REGISTER -5 //неверный регистр
#define ERROR_COMMAND -6 //неправильная команда
#define ERROR_OPERAND -7 //неправильный операнд
#define ERROR_SIGN -8 //отсутствует признак команды

#define MSIZE 100
#define CMDNUM 38

int sc_memory[MSIZE];
int sc_reg_flags;

int sc_memoryInit();
int sc_regSet(int reg, int value);
int sc_memorySet(int addr, int value);
int sc_memoryGet(int addr, int *value);
int sc_memorySave(char *filename);
int sc_memoryLoad(char *filename);
int sc_regInit();
int sc_regGet(int reg, int *value);
int sc_commandEncode(int command, int operand, int *value);
int sc_commandDecode(int value, int *command, int *operand);

#endif
