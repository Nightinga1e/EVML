#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>

int main(void)
{
	int err;
	int count = 2;
	
	int fd = open("file.txt", O_WRONLY);
	
	err = write(fd, &count, sizeof(count));

  return 0;
} 
