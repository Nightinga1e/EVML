#include "mySimpleComputer.h"

int sc_memoryInit()
{
	int i;
	for(i = 0; i < MSIZE; i++) {
		sc_memory[i] = 0;
	}
	return 0;
}

int sc_memorySet(int address, int value)
{
	if(address >= 0 && address < MSIZE) {
		sc_memory[address] = value;
		return 0;
	} else {
		return ERROR_ADDRESS;
	}
}

int sc_memoryGet(int address, int* value)
{
	if(address >= 0 && address < MSIZE) {
		*value = sc_memory[address];
		return 0;
	} else {
		return ERROR_ADDRESS;
	}
}

int sc_memorySave(char* filename)
{
	FILE* s_file;
	s_file = fopen(filename, "wb");
	
	if(s_file == NULL) {
		return ERROR_OPEN_FILE;
	}
	
	int badrec;
	badrec = fwrite(sc_memory, sizeof(int), MSIZE, s_file);
	fclose(s_file);
	
	if(badrec != MSIZE) {
		return ERROR_FILE_WR;
	} else {
		return 0;
	}
}

int sc_memoryLoad(char* filename)
{
	FILE* l_file;
	l_file = fopen(filename, "rb");
	
	if(l_file == NULL) {
		return ERROR_OPEN_FILE;
	}
	
	int badread;
	badread = fread(sc_memory, sizeof(int), MSIZE, l_file);
	
	if(badread != MSIZE) {
		return ERROR_FILE_WR;
}

int sc_regInit()
{
	sc_reg_flags = 0;
	return 0;
}

int sc_regSet(int regist, int value)
{
	if(regist >= 0 && regist < 5) {
		if(value == 1) {
			BIT_SET(sc_reg_flags, regist);
		} else if(value == 0) {
					BIT_CLEAR(sc_reg_flags, regist);
				} else return ERROR_VALUE;
	} else {
		return ERROR_REGISTER;
	}
	return 0;
}

int sc_regGet(int regist, int* value)
{
	if(regist >= 0 && regist < 5) {
		*value = BIT_GET(sc_reg_flags, regist);
	} else {
		return ERROR_REGISTER;
	}
	return 0;
}

int sc_commandEncode(int command, int operand, int* value)
{
	int i = 0;
	if (operand >= 0x00 && operand <= 0x7F) {
		while(i < CMDNUM && command != commands[i]) {
			i++;
		}
		if (i != CMDNUM) {
			*value = (command << 7) | operand;
			return 0;
		} else return ERROR_COMMAND;
	} else return ERROR_OPERAND;
}

int sc_commandDecode(int value, int* command, int* operand)
{
	int sign_command;
	int temp_command, temp_operand;
	
	sign_command = (value >> 14) & 1;
	
	if (sign_command == 0) {
		temp_command = (value >> 7) & 0x7F;
		temp_operand = value & 0x7F;
		
		int i;
		while(i < CMDNUM && temp_command != commands[i]) {
			i++;
		}
		if(i != CMDNUM) {
			*command = temp_command;
			*operand = temp_operand;
			return 0;
		} else return ERROR_COMMAND;
	} else return ERROR_SIGN;
}

