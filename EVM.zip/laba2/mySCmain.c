#include <stdio.h>
#include "mySimpComp.h"

int main() {
	
	int i, f, badrec;
	int k;
	int *value = &k;
	char g[4] = "aaaa";
	int a = 4;
	int r = &a;
	
	for (int i = 0; i < 20; i++)
		printf("%d ", sc_memory[i]);
		
	f = open("savefile.txt", O_CREAT | O_WRONLY);
	badrec = write(f, r, sizeof(int));
	
	i =  sc_memoryInit();
	printf("i =  %d\n", i);
	
	i = sc_memorySet(8, 15);
	printf("i =  %d\n", i);
	
	i = sc_memorySet(102, 14);
	printf("i =  %d\n", i);
	
	i = sc_memoryGet(8, value);
	printf("i = %d, value = %d\n", i, *value);
	
	/*i = sc_memorySave("savefile.txt");
	printf("i =  %d\n", i);*/
	/*i = sc_memoryLoad("savefile");
	printf("i =  %d\n", i);*/
	
	i = sc_regInit();
	printf("i =  %d\n", i);
	
	i = sc_regSet(3, 1);
	printf("%d, reg = %d\n", i, sc_reg_flags);
	
	i = sc_regGet(3, value);
	printf("i = %d, value = %d\n", i, *value);
	
	i = sc_commandEncode(0x33, 0x59, value);
	printf("i = %d, value = %x\n", i, *value);
	
	int p;
	int *value1 = &p;
	int o = *value;
	i = sc_commandDecode(o, value, value1);
	printf("i = %d, command = %x, operand = %x\n", i, *value, *value1);
	
	printf("\n");
	int y;
	for(y = 0; y < 7; ++y) {
		printf("%d", BIT_GET(0x33, y));
	}
	printf("\n");
	for(y = 0; y < 7; ++y) {
		printf("%d", BIT_GET(0x59, y));
	}
	printf("\n");
	for(y = 0; y < 15; ++y) {
		printf("%d", BIT_GET(o, y));
	}
	printf("\n");
	return 0;
}
