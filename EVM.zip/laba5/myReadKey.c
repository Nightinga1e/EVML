#include "myReadKey.h"

int rk_readkey(enum keys *key)
{
	struct termios term;
	char buf[16];
	int num_read;
	
	if (tcgetattr(0, &term) != 0)
		return -1;
		
	if (rk_mytermregime(0, 0, 1, 0, 1) != 0)
		return -1;
		
	num_read = read(0, buf, 15);
	
	if (num_read < 0)
		return -1;
	buf[num_read] = '\0';
	
	if (strcmp(buf, "l") == 0)
		*key = KEY_l;
	else
	if (strcmp(buf, "s") == 0)
		*key = KEY_s;
	else
	if (strcmp(buf, "r") == 0)
		*key = KEY_r;
	else
	if (strcmp(buf, "t") == 0)
		*key = KEY_t;
	else
	if (strcmp(buf, "i") == 0)
		*key = KEY_i;
	else
	if (strcmp(buf, "\n") == 0)
		*key = KEY_enter;
	else
	if (strcmp(buf, "\E[15~") == 0)
		*key = KEY_f5;
	else
	if (strcmp(buf, "\E[17~") == 0)
		*key = KEY_f6;
	else
	if (strcmp(buf, "\EOB") == 0)
		*key = KEY_down;
	else
	if (strcmp(buf, "\EOC") == 0)
		*key = KEY_right;
	else
	if (strcmp(buf, "\EOA") == 0)
		*key = KEY_up;
	else
	if (strcmp(buf, "\EOD") == 0)
		*key = KEY_left;
		
	if (tcsetattr(0, TCSADRAIN, &term) != 0)
		return -1;

	return 0;
}

int rk_mytermsave()
{
	int e;
	FILE *save;
	struct termios sterm;
	
	e = tcgetattr(0, &sterm);
	
	if ((save = fopen("termsave", "wb")) == NULL)
		return -1;
	fwrite(&sterm, sizeof(sterm), 1, save);
	fclose(save);
	
	return e;
}

int rk_mytermrestore()
{
	struct termios sterm;
	FILE *load;
	
	if ((load = fopen("termsave", "rb")) == NULL)
		return -1;
		
	if (fread(&sterm, sizeof(sterm), 1, load) > 0) {
		if (tcsetattr(0, TCSADRAIN, &sterm) != 0)
			return -1;
	} else
		return -1;
	return 0;
}


int rk_mytermregime(int regime, int vtime, int vmin, int echo, int sigint)
{
	struct termios term;
	
	if (tcgetattr(0, &term) != 0)
		return -1;
	if (regime == 1)
		term.c_lflag |= ICANON;
	else
	if (regime == 0)
		term.c_lflag &= ~ICANON;
	else
		return -1;
		
	if (regime == 0) {
		term.c_cc[VTIME] = vtime;
		term.c_cc[VMIN] = vmin;
		if (echo == 1)
			term.c_lflag |= ECHO;
		else
		if (echo == 0)
			term.c_lflag &= ~ECHO;
		else
			return -1;
		if (sigint == 1)
			term.c_lflag |= ISIG;
		else
		if (sigint == 0)
			term.c_lflag &= ~ISIG;
		else
			return -1;
	}
	if (tcsetattr(0, TCSADRAIN, &term) != 0)
		return -1;
	
	return 0;
}
