#include "myReadKey.h"

int main() {
	enum keys k;
	rk_mytermsave();
	rk_readkey(&k);
	
	printf("%d\n", k);
	return 0;
}
